## cuad_qwen32b

- **Schema:** `data/cuad_schema.json`
- **Data:** `data/cuad_test.jsonl`
- **Model:** `_`
- **Fields gated (11):** `has_anti_assignment`, `has_cap_on_liability`, `has_audit_rights`, `has_exclusivity`, `has_change_of_control`, `has_non_compete`, `has_liquidated_damages`, `has_most_favored_nation`, `governing_law`, `renewal_term`, `expiration_type`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `has_anti_assignment` | BOOL | — | 49 | 35% | 0.933 |
| `has_cap_on_liability` | BOOL | — | 49 | 53% | 0.923 |
| `has_audit_rights` | BOOL | — | 49 | 61% | 0.777 |
| `has_exclusivity` | BOOL | — | 49 | 92% | 0.794 |
| `has_change_of_control` | BOOL | — | 49 | 84% | 0.872 |
| `has_non_compete` | BOOL | — | 49 | 78% | 0.818 |
| `has_liquidated_damages` | BOOL | — | 49 | 90% | 0.833 |
| `has_most_favored_nation` | BOOL | — | 49 | 94% | 0.933 |
| `governing_law` | ENUM12 | `not_specified` | 49 | 27% | 0.690 |
| `renewal_term` | ENUM6 | `not_specified` | 49 | 55% | 0.701 |
| `expiration_type` | ENUM3 | `not_specified` | 49 | 63% | 0.760 |

### has_anti_assignment

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 35% · mean margin: 0.933

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 11 | 0.999 | 0.994 – 1.000 |
| `True` | 38 | 0.914 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 35% |
| 0.05 | 48 | 1 | 33% |
| 0.10 | 48 | 1 | 33% |
| 0.15 | 48 | 1 | 33% |
| 0.20 | 46 | 3 | 35% |
| 0.25 | 46 | 3 | 35% |
| 0.30 | 46 | 3 | 35% |
| 0.35 | 46 | 3 | 35% |
| 0.40 | 46 | 3 | 35% |
| 0.50 | 46 | 3 | 35% |

### has_cap_on_liability

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 53% · mean margin: 0.923

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 23 | 0.922 | 0.000 – 1.000 |
| `True` | 26 | 0.924 | 0.062 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 53% |
| 0.05 | 48 | 1 | 54% |
| 0.10 | 47 | 2 | 53% |
| 0.15 | 47 | 2 | 53% |
| 0.20 | 47 | 2 | 53% |
| 0.25 | 47 | 2 | 53% |
| 0.30 | 47 | 2 | 53% |
| 0.35 | 47 | 2 | 53% |
| 0.40 | 47 | 2 | 53% |
| 0.50 | 45 | 4 | 51% |

### has_audit_rights

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 61% · mean margin: 0.777

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 24 | 0.885 | 0.062 – 1.000 |
| `True` | 25 | 0.673 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 61% |
| 0.05 | 48 | 1 | 60% |
| 0.10 | 46 | 3 | 61% |
| 0.15 | 44 | 5 | 64% |
| 0.20 | 44 | 5 | 64% |
| 0.25 | 44 | 5 | 64% |
| 0.30 | 44 | 5 | 64% |
| 0.35 | 40 | 9 | 68% |
| 0.40 | 40 | 9 | 68% |
| 0.50 | 38 | 11 | 71% |

### has_exclusivity

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 92% · mean margin: 0.794

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 32 | 0.833 | 0.062 – 1.000 |
| `True` | 17 | 0.721 | 0.062 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 92% |
| 0.05 | 49 | 0 | 92% |
| 0.10 | 46 | 3 | 96% |
| 0.15 | 45 | 4 | 96% |
| 0.20 | 43 | 6 | 95% |
| 0.25 | 43 | 6 | 95% |
| 0.30 | 43 | 6 | 95% |
| 0.35 | 43 | 6 | 95% |
| 0.40 | 43 | 6 | 95% |
| 0.50 | 42 | 7 | 98% |

### has_change_of_control

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 84% · mean margin: 0.872

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 40 | 0.892 | 0.186 – 1.000 |
| `True` | 9 | 0.784 | 0.125 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 84% |
| 0.05 | 49 | 0 | 84% |
| 0.10 | 49 | 0 | 84% |
| 0.15 | 48 | 1 | 83% |
| 0.20 | 47 | 2 | 85% |
| 0.25 | 47 | 2 | 85% |
| 0.30 | 47 | 2 | 85% |
| 0.35 | 45 | 4 | 84% |
| 0.40 | 45 | 4 | 84% |
| 0.50 | 43 | 6 | 86% |

### has_non_compete

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 78% · mean margin: 0.818

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 39 | 0.831 | 0.062 – 1.000 |
| `True` | 10 | 0.764 | 0.303 – 0.992 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 78% |
| 0.05 | 49 | 0 | 78% |
| 0.10 | 48 | 1 | 79% |
| 0.15 | 48 | 1 | 79% |
| 0.20 | 48 | 1 | 79% |
| 0.25 | 47 | 2 | 79% |
| 0.30 | 47 | 2 | 79% |
| 0.35 | 46 | 3 | 78% |
| 0.40 | 45 | 4 | 80% |
| 0.50 | 42 | 7 | 81% |

### has_liquidated_damages

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 90% · mean margin: 0.833

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 44 | 0.859 | 0.186 – 1.000 |
| `True` | 5 | 0.605 | 0.000 – 0.969 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 90% |
| 0.05 | 48 | 1 | 90% |
| 0.10 | 48 | 1 | 90% |
| 0.15 | 48 | 1 | 90% |
| 0.20 | 47 | 2 | 89% |
| 0.25 | 46 | 3 | 91% |
| 0.30 | 46 | 3 | 91% |
| 0.35 | 45 | 4 | 91% |
| 0.40 | 44 | 5 | 91% |
| 0.50 | 43 | 6 | 91% |

### has_most_favored_nation

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 94% · mean margin: 0.933

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 47 | 0.932 | 0.244 – 1.000 |
| `True` | 2 | 0.958 | 0.915 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 94% |
| 0.05 | 49 | 0 | 94% |
| 0.10 | 49 | 0 | 94% |
| 0.15 | 49 | 0 | 94% |
| 0.20 | 49 | 0 | 94% |
| 0.25 | 48 | 1 | 96% |
| 0.30 | 48 | 1 | 96% |
| 0.35 | 48 | 1 | 96% |
| 0.40 | 48 | 1 | 96% |
| 0.50 | 48 | 1 | 96% |

### governing_law

- role: `ENUM12` · abstain target: `not_specified` · n: 49 · baseline acc: 27% · mean margin: 0.690

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `California` | 4 | 0.563 | 0.236 – 0.994 |
| `Delaware` | 8 | 0.650 | 0.049 – 0.994 |
| `Florida` | 1 | 0.862 | 0.862 – 0.862 |
| `Illinois` | 2 | 0.166 | 0.113 – 0.219 |
| `Nevada` | 1 | 0.898 | 0.898 – 0.898 |
| `New York` | 8 | 0.605 | 0.148 – 0.991 |
| `Pennsylvania` | 2 | 0.974 | 0.950 – 0.998 |
| `People's Republic of China` | 1 | 0.994 | 0.994 – 0.994 |
| `Texas` | 2 | 0.561 | 0.121 – 1.000 |
| `not_specified` | 5 | 0.945 | 0.807 – 0.999 |
| `other` | 15 | 0.709 | 0.000 – 0.994 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 44 | 20% | 20% | 0% |
| 0.05 | 47 | 2 | 42 | 21% | 20% | 0% |
| 0.10 | 47 | 2 | 42 | 21% | 20% | 0% |
| 0.15 | 43 | 6 | 38 | 21% | 18% | 0% |
| 0.20 | 43 | 6 | 38 | 21% | 18% | 0% |
| 0.25 | 40 | 9 | 35 | 20% | 16% | 0% |
| 0.30 | 40 | 9 | 35 | 20% | 16% | 0% |
| 0.35 | 38 | 11 | 33 | 21% | 16% | 0% |
| 0.40 | 38 | 11 | 33 | 21% | 16% | 0% |
| 0.50 | 35 | 14 | 30 | 20% | 14% | 0% |

### renewal_term

- role: `ENUM6` · abstain target: `not_specified` · n: 49 · baseline acc: 55% · mean margin: 0.701

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `fixed_term` | 6 | 0.745 | 0.489 – 0.979 |
| `not_specified` | 34 | 0.704 | 0.000 – 1.000 |
| `perpetual` | 1 | 0.702 | 0.702 – 0.702 |
| `successive_1_year` | 7 | 0.735 | 0.384 – 0.994 |
| `successive_multi_year` | 1 | 0.125 | 0.125 – 0.125 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 15 | 0% | 0% | 0% |
| 0.05 | 47 | 2 | 15 | 0% | 0% | 6% |
| 0.10 | 47 | 2 | 15 | 0% | 0% | 6% |
| 0.15 | 44 | 5 | 14 | 0% | 0% | 12% |
| 0.20 | 44 | 5 | 14 | 0% | 0% | 12% |
| 0.25 | 43 | 6 | 14 | 0% | 0% | 15% |
| 0.30 | 43 | 6 | 14 | 0% | 0% | 15% |
| 0.35 | 42 | 7 | 14 | 0% | 0% | 18% |
| 0.40 | 40 | 9 | 13 | 0% | 0% | 21% |
| 0.50 | 33 | 16 | 9 | 0% | 0% | 29% |

### expiration_type

- role: `ENUM3` · abstain target: `not_specified` · n: 49 · baseline acc: 63% · mean margin: 0.760

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `not_specified` | 21 | 0.806 | 0.061 – 1.000 |
| `perpetual` | 6 | 0.943 | 0.704 – 0.999 |
| `specific_date` | 22 | 0.667 | 0.000 – 1.000 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 28 | 39% | 39% | 0% |
| 0.05 | 47 | 2 | 26 | 35% | 32% | 0% |
| 0.10 | 46 | 3 | 26 | 35% | 32% | 5% |
| 0.15 | 44 | 5 | 25 | 32% | 29% | 10% |
| 0.20 | 44 | 5 | 25 | 32% | 29% | 10% |
| 0.25 | 42 | 7 | 24 | 33% | 29% | 14% |
| 0.30 | 42 | 7 | 24 | 33% | 29% | 14% |
| 0.35 | 41 | 8 | 23 | 35% | 29% | 14% |
| 0.40 | 39 | 10 | 21 | 33% | 25% | 14% |
| 0.50 | 37 | 12 | 20 | 30% | 21% | 19% |

