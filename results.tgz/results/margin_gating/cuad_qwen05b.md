## cuad_qwen05b

- **Schema:** `data/cuad_schema.json`
- **Data:** `data/cuad_test.jsonl`
- **Model:** `Qwen/Qwen2.5-0.5B-Instruct`
- **Fields gated (11):** `has_anti_assignment`, `has_cap_on_liability`, `has_audit_rights`, `has_exclusivity`, `has_change_of_control`, `has_non_compete`, `has_liquidated_damages`, `has_most_favored_nation`, `governing_law`, `renewal_term`, `expiration_type`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `has_anti_assignment` | BOOL | — | 49 | 27% | 0.190 |
| `has_cap_on_liability` | BOOL | — | 49 | 41% | 0.237 |
| `has_audit_rights` | BOOL | — | 49 | 57% | 0.250 |
| `has_exclusivity` | BOOL | — | 49 | 67% | 0.233 |
| `has_change_of_control` | BOOL | — | 49 | 88% | 0.500 |
| `has_non_compete` | BOOL | — | 49 | 82% | 0.314 |
| `has_liquidated_damages` | BOOL | — | 49 | 86% | 0.507 |
| `has_most_favored_nation` | BOOL | — | 49 | 94% | 0.364 |
| `governing_law` | ENUM12 | `not_specified` | 49 | 18% | 0.199 |
| `renewal_term` | ENUM6 | `not_specified` | 49 | 2% | 0.451 |
| `expiration_type` | ENUM3 | `not_specified` | 49 | 49% | 0.255 |

### has_anti_assignment

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 27% · mean margin: 0.190

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 11 | 0.230 | 0.076 – 0.507 |
| `True` | 38 | 0.178 | 0.007 – 0.391 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 27% |
| 0.05 | 42 | 7 | 26% |
| 0.10 | 34 | 15 | 26% |
| 0.15 | 26 | 23 | 19% |
| 0.20 | 22 | 27 | 23% |
| 0.25 | 18 | 31 | 22% |
| 0.30 | 10 | 39 | 30% |
| 0.35 | 6 | 43 | 50% |
| 0.40 | 3 | 46 | 100% |
| 0.50 | 1 | 48 | 100% |

### has_cap_on_liability

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 41% · mean margin: 0.237

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 23 | 0.214 | 0.005 – 0.390 |
| `True` | 26 | 0.257 | 0.010 – 0.494 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 41% |
| 0.05 | 43 | 6 | 47% |
| 0.10 | 41 | 8 | 44% |
| 0.15 | 38 | 11 | 39% |
| 0.20 | 33 | 16 | 39% |
| 0.25 | 26 | 23 | 42% |
| 0.30 | 17 | 32 | 35% |
| 0.35 | 6 | 43 | 33% |
| 0.40 | 1 | 48 | 0% |
| 0.50 | 0 | 49 | 0% |

### has_audit_rights

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 57% · mean margin: 0.250

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 24 | 0.351 | 0.073 – 0.584 |
| `True` | 25 | 0.153 | 0.030 – 0.353 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 57% |
| 0.05 | 46 | 3 | 59% |
| 0.10 | 38 | 11 | 66% |
| 0.15 | 31 | 18 | 74% |
| 0.20 | 28 | 21 | 71% |
| 0.25 | 23 | 26 | 74% |
| 0.30 | 19 | 30 | 84% |
| 0.35 | 14 | 35 | 93% |
| 0.40 | 10 | 39 | 100% |
| 0.50 | 4 | 45 | 100% |

### has_exclusivity

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 67% · mean margin: 0.233

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 32 | 0.288 | 0.007 – 0.612 |
| `True` | 17 | 0.129 | 0.006 – 0.346 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 67% |
| 0.05 | 38 | 11 | 76% |
| 0.10 | 34 | 15 | 74% |
| 0.15 | 30 | 19 | 77% |
| 0.20 | 25 | 24 | 80% |
| 0.25 | 22 | 27 | 77% |
| 0.30 | 18 | 31 | 89% |
| 0.35 | 9 | 40 | 100% |
| 0.40 | 8 | 41 | 100% |
| 0.50 | 7 | 42 | 100% |

### has_change_of_control

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 88% · mean margin: 0.500

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 40 | 0.531 | 0.001 – 0.819 |
| `True` | 9 | 0.359 | 0.098 – 0.650 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 88% |
| 0.05 | 46 | 3 | 89% |
| 0.10 | 45 | 4 | 89% |
| 0.15 | 43 | 6 | 88% |
| 0.20 | 42 | 7 | 88% |
| 0.25 | 41 | 8 | 90% |
| 0.30 | 40 | 9 | 90% |
| 0.35 | 39 | 10 | 90% |
| 0.40 | 38 | 11 | 89% |
| 0.50 | 32 | 17 | 88% |

### has_non_compete

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 82% · mean margin: 0.314

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 39 | 0.316 | 0.011 – 0.696 |
| `True` | 10 | 0.308 | 0.059 – 0.768 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 82% |
| 0.05 | 46 | 3 | 83% |
| 0.10 | 43 | 6 | 86% |
| 0.15 | 36 | 13 | 83% |
| 0.20 | 29 | 20 | 83% |
| 0.25 | 25 | 24 | 80% |
| 0.30 | 24 | 25 | 79% |
| 0.35 | 20 | 29 | 85% |
| 0.40 | 16 | 33 | 88% |
| 0.50 | 12 | 37 | 92% |

### has_liquidated_damages

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 86% · mean margin: 0.507

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 44 | 0.526 | 0.257 – 0.776 |
| `True` | 5 | 0.337 | 0.128 – 0.485 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 86% |
| 0.05 | 49 | 0 | 86% |
| 0.10 | 49 | 0 | 86% |
| 0.15 | 48 | 1 | 88% |
| 0.20 | 48 | 1 | 88% |
| 0.25 | 47 | 2 | 89% |
| 0.30 | 45 | 4 | 91% |
| 0.35 | 44 | 5 | 91% |
| 0.40 | 39 | 10 | 90% |
| 0.50 | 27 | 22 | 96% |

### has_most_favored_nation

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 94% · mean margin: 0.364

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 47 | 0.369 | 0.056 – 0.749 |
| `True` | 2 | 0.232 | 0.136 – 0.328 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 94% |
| 0.05 | 49 | 0 | 94% |
| 0.10 | 47 | 2 | 96% |
| 0.15 | 43 | 6 | 98% |
| 0.20 | 40 | 9 | 98% |
| 0.25 | 37 | 12 | 97% |
| 0.30 | 33 | 16 | 97% |
| 0.35 | 26 | 23 | 100% |
| 0.40 | 20 | 29 | 100% |
| 0.50 | 10 | 39 | 100% |

### governing_law

- role: `ENUM12` · abstain target: `not_specified` · n: 49 · baseline acc: 18% · mean margin: 0.199

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `California` | 4 | 0.110 | 0.031 – 0.285 |
| `Delaware` | 8 | 0.152 | 0.006 – 0.294 |
| `Florida` | 1 | 0.035 | 0.035 – 0.035 |
| `Illinois` | 2 | 0.036 | 0.015 – 0.056 |
| `Nevada` | 1 | 0.177 | 0.177 – 0.177 |
| `New York` | 8 | 0.170 | 0.008 – 0.377 |
| `Pennsylvania` | 2 | 0.109 | 0.045 – 0.173 |
| `People's Republic of China` | 1 | 0.447 | 0.447 – 0.447 |
| `Texas` | 2 | 0.335 | 0.206 – 0.464 |
| `not_specified` | 5 | 0.306 | 0.127 – 0.493 |
| `other` | 15 | 0.238 | 0.013 – 0.464 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 44 | 9% | 9% | 0% |
| 0.05 | 41 | 8 | 36 | 8% | 7% | 0% |
| 0.10 | 33 | 16 | 28 | 4% | 2% | 0% |
| 0.15 | 27 | 22 | 23 | 4% | 2% | 20% |
| 0.20 | 21 | 28 | 17 | 6% | 2% | 20% |
| 0.25 | 17 | 32 | 13 | 0% | 0% | 20% |
| 0.30 | 14 | 35 | 11 | 0% | 0% | 40% |
| 0.35 | 9 | 40 | 8 | 0% | 0% | 80% |
| 0.40 | 6 | 43 | 5 | 0% | 0% | 80% |
| 0.50 | 0 | 49 | 0 | 0% | 0% | 100% |

### renewal_term

- role: `ENUM6` · abstain target: `not_specified` · n: 49 · baseline acc: 2% · mean margin: 0.451

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `fixed_term` | 6 | 0.449 | 0.405 – 0.470 |
| `not_specified` | 34 | 0.453 | 0.374 – 0.485 |
| `perpetual` | 1 | 0.455 | 0.455 – 0.455 |
| `successive_1_year` | 7 | 0.450 | 0.422 – 0.479 |
| `successive_multi_year` | 1 | 0.435 | 0.435 – 0.435 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.05 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.10 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.15 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.20 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.25 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.30 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.35 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.40 | 48 | 1 | 15 | 7% | 7% | 3% |
| 0.50 | 0 | 49 | 0 | 0% | 0% | 100% |

### expiration_type

- role: `ENUM3` · abstain target: `not_specified` · n: 49 · baseline acc: 49% · mean margin: 0.255

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `not_specified` | 21 | 0.238 | 0.008 – 0.706 |
| `perpetual` | 6 | 0.257 | 0.024 – 0.490 |
| `specific_date` | 22 | 0.271 | 0.000 – 0.705 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 28 | 75% | 75% | 0% |
| 0.05 | 42 | 7 | 25 | 80% | 71% | 19% |
| 0.10 | 36 | 13 | 21 | 76% | 57% | 29% |
| 0.15 | 34 | 15 | 21 | 76% | 57% | 38% |
| 0.20 | 27 | 22 | 17 | 76% | 46% | 52% |
| 0.25 | 21 | 28 | 14 | 79% | 39% | 67% |
| 0.30 | 16 | 33 | 11 | 82% | 32% | 76% |
| 0.35 | 14 | 35 | 9 | 78% | 25% | 76% |
| 0.40 | 11 | 38 | 7 | 86% | 21% | 81% |
| 0.50 | 5 | 44 | 2 | 100% | 7% | 86% |

