## flights_qwen32b

- **Schema:** `data/Flights_1_schema_pcl.json`
- **Data:** `data/Flights_1_test_pcl.jsonl`
- **Model:** `_`
- **Fields gated (5):** `passengers`, `seating_class`, `number_stops`, `refundable`, `airlines`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `passengers` | ENUM4 | — | 50 | 100% | 0.959 |
| `seating_class` | ENUM4 | — | 50 | 100% | 0.986 |
| `number_stops` | ENUM2 | — | 50 | 70% | 0.561 |
| `refundable` | ENUM3 | `ambiguous` | 50 | 26% | 0.455 |
| `airlines` | ENUM8 | — | 50 | 62% | 0.722 |

### passengers

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 100% · mean margin: 0.959

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `1` | 32 | 0.946 | 0.348 – 1.000 |
| `2` | 7 | 0.998 | 0.992 – 1.000 |
| `3` | 5 | 0.999 | 0.998 – 1.000 |
| `4` | 6 | 0.952 | 0.718 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 100% |
| 0.05 | 50 | 0 | 100% |
| 0.10 | 50 | 0 | 100% |
| 0.15 | 50 | 0 | 100% |
| 0.20 | 50 | 0 | 100% |
| 0.25 | 50 | 0 | 100% |
| 0.30 | 50 | 0 | 100% |
| 0.35 | 49 | 1 | 100% |
| 0.40 | 49 | 1 | 100% |
| 0.50 | 49 | 1 | 100% |

### seating_class

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 100% · mean margin: 0.986

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Economy` | 44 | 0.984 | 0.807 – 1.000 |
| `Premium Economy` | 6 | 1.000 | 0.999 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 100% |
| 0.05 | 50 | 0 | 100% |
| 0.10 | 50 | 0 | 100% |
| 0.15 | 50 | 0 | 100% |
| 0.20 | 50 | 0 | 100% |
| 0.25 | 50 | 0 | 100% |
| 0.30 | 50 | 0 | 100% |
| 0.35 | 50 | 0 | 100% |
| 0.40 | 50 | 0 | 100% |
| 0.50 | 50 | 0 | 100% |

### number_stops

- role: `ENUM2` · abstain target: none · n: 50 · baseline acc: 70% · mean margin: 0.561

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `0` | 27 | 0.587 | 0.000 – 1.000 |
| `1` | 23 | 0.531 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 70% |
| 0.05 | 46 | 4 | 74% |
| 0.10 | 45 | 5 | 76% |
| 0.15 | 41 | 9 | 78% |
| 0.20 | 39 | 11 | 79% |
| 0.25 | 36 | 14 | 81% |
| 0.30 | 36 | 14 | 81% |
| 0.35 | 35 | 15 | 80% |
| 0.40 | 30 | 20 | 83% |
| 0.50 | 26 | 24 | 88% |

### refundable

- role: `ENUM3` · abstain target: `ambiguous` · n: 50 · baseline acc: 26% · mean margin: 0.455

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 9 | 0.912 | 0.509 – 1.000 |
| `True` | 5 | 0.946 | 0.850 – 1.000 |
| `ambiguous` | 36 | 0.272 | 0.062 – 0.924 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_ambiguous`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 14 | 93% | 93% | 0% |
| 0.05 | 50 | 0 | 14 | 93% | 93% | 0% |
| 0.10 | 44 | 6 | 14 | 93% | 93% | 17% |
| 0.15 | 38 | 12 | 14 | 93% | 93% | 33% |
| 0.20 | 32 | 18 | 14 | 93% | 93% | 50% |
| 0.25 | 28 | 22 | 14 | 93% | 93% | 61% |
| 0.30 | 28 | 22 | 14 | 93% | 93% | 61% |
| 0.35 | 26 | 24 | 14 | 93% | 93% | 67% |
| 0.40 | 21 | 29 | 14 | 93% | 93% | 81% |
| 0.50 | 17 | 33 | 14 | 93% | 93% | 92% |

### airlines

- role: `ENUM8` · abstain target: none · n: 50 · baseline acc: 62% · mean margin: 0.722

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Air Canada` | 2 | 0.336 | 0.172 – 0.500 |
| `Alaska Airlines` | 5 | 0.700 | 0.094 – 1.000 |
| `American Airlines` | 22 | 0.594 | 0.055 – 1.000 |
| `Delta Airlines` | 10 | 0.861 | 0.332 – 1.000 |
| `Southwest Airlines` | 5 | 1.000 | 1.000 – 1.000 |
| `United Airlines` | 6 | 0.872 | 0.230 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 62% |
| 0.05 | 50 | 0 | 62% |
| 0.10 | 46 | 4 | 67% |
| 0.15 | 45 | 5 | 69% |
| 0.20 | 43 | 7 | 72% |
| 0.25 | 41 | 9 | 76% |
| 0.30 | 41 | 9 | 76% |
| 0.35 | 38 | 12 | 79% |
| 0.40 | 37 | 13 | 81% |
| 0.50 | 32 | 18 | 91% |

