## cuad_qwen05b_pcl

- **Schema:** `data/cuad_schema.json`
- **Data:** `data/cuad_test.jsonl`
- **Model:** `_`
- **Fields gated (11):** `has_anti_assignment`, `has_cap_on_liability`, `has_audit_rights`, `has_exclusivity`, `has_change_of_control`, `has_non_compete`, `has_liquidated_damages`, `has_most_favored_nation`, `governing_law`, `renewal_term`, `expiration_type`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `has_anti_assignment` | BOOL | — | 49 | 24% | 0.866 |
| `has_cap_on_liability` | BOOL | — | 49 | 53% | 0.680 |
| `has_audit_rights` | BOOL | — | 49 | 71% | 0.656 |
| `has_exclusivity` | BOOL | — | 49 | 67% | 0.510 |
| `has_change_of_control` | BOOL | — | 49 | 82% | 0.790 |
| `has_non_compete` | BOOL | — | 49 | 59% | 0.569 |
| `has_liquidated_damages` | BOOL | — | 49 | 90% | 0.961 |
| `has_most_favored_nation` | BOOL | — | 49 | 96% | 0.967 |
| `governing_law` | ENUM12 | `not_specified` | 49 | 29% | 0.513 |
| `renewal_term` | ENUM6 | `not_specified` | 49 | 69% | 0.627 |
| `expiration_type` | ENUM3 | `not_specified` | 49 | 45% | 0.551 |

### has_anti_assignment

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 24% · mean margin: 0.866

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 11 | 0.901 | 0.303 – 1.000 |
| `True` | 38 | 0.856 | 0.186 – 0.999 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 24% |
| 0.05 | 49 | 0 | 24% |
| 0.10 | 49 | 0 | 24% |
| 0.15 | 49 | 0 | 24% |
| 0.20 | 48 | 1 | 25% |
| 0.25 | 48 | 1 | 25% |
| 0.30 | 48 | 1 | 25% |
| 0.35 | 46 | 3 | 22% |
| 0.40 | 46 | 3 | 22% |
| 0.50 | 46 | 3 | 22% |

### has_cap_on_liability

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 53% · mean margin: 0.680

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 23 | 0.798 | 0.062 – 1.000 |
| `True` | 26 | 0.575 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 53% |
| 0.05 | 48 | 1 | 52% |
| 0.10 | 46 | 3 | 52% |
| 0.15 | 44 | 5 | 55% |
| 0.20 | 43 | 6 | 53% |
| 0.25 | 42 | 7 | 55% |
| 0.30 | 42 | 7 | 55% |
| 0.35 | 41 | 8 | 54% |
| 0.40 | 38 | 11 | 55% |
| 0.50 | 38 | 11 | 55% |

### has_audit_rights

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 71% · mean margin: 0.656

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 24 | 0.848 | 0.125 – 1.000 |
| `True` | 25 | 0.472 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 71% |
| 0.05 | 48 | 1 | 71% |
| 0.10 | 46 | 3 | 72% |
| 0.15 | 44 | 5 | 75% |
| 0.20 | 38 | 11 | 79% |
| 0.25 | 38 | 11 | 79% |
| 0.30 | 38 | 11 | 79% |
| 0.35 | 35 | 14 | 77% |
| 0.40 | 33 | 16 | 79% |
| 0.50 | 31 | 18 | 77% |

### has_exclusivity

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 67% · mean margin: 0.510

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 32 | 0.595 | 0.000 – 1.000 |
| `True` | 17 | 0.349 | 0.000 – 0.986 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 67% |
| 0.05 | 47 | 2 | 68% |
| 0.10 | 44 | 5 | 68% |
| 0.15 | 38 | 11 | 74% |
| 0.20 | 34 | 15 | 74% |
| 0.25 | 33 | 16 | 76% |
| 0.30 | 33 | 16 | 76% |
| 0.35 | 30 | 19 | 83% |
| 0.40 | 26 | 23 | 88% |
| 0.50 | 24 | 25 | 92% |

### has_change_of_control

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 82% · mean margin: 0.790

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 40 | 0.805 | 0.000 – 1.000 |
| `True` | 9 | 0.723 | 0.359 – 0.985 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 82% |
| 0.05 | 48 | 1 | 83% |
| 0.10 | 48 | 1 | 83% |
| 0.15 | 48 | 1 | 83% |
| 0.20 | 47 | 2 | 85% |
| 0.25 | 46 | 3 | 87% |
| 0.30 | 46 | 3 | 87% |
| 0.35 | 44 | 5 | 86% |
| 0.40 | 43 | 6 | 86% |
| 0.50 | 41 | 8 | 88% |

### has_non_compete

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 59% · mean margin: 0.569

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 39 | 0.573 | 0.062 – 1.000 |
| `True` | 10 | 0.553 | 0.125 – 0.963 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 59% |
| 0.05 | 49 | 0 | 59% |
| 0.10 | 47 | 2 | 60% |
| 0.15 | 45 | 4 | 60% |
| 0.20 | 44 | 5 | 59% |
| 0.25 | 43 | 6 | 60% |
| 0.30 | 43 | 6 | 60% |
| 0.35 | 38 | 11 | 63% |
| 0.40 | 34 | 15 | 71% |
| 0.50 | 24 | 25 | 79% |

### has_liquidated_damages

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 90% · mean margin: 0.961

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 44 | 0.979 | 0.555 – 1.000 |
| `True` | 5 | 0.805 | 0.125 – 0.998 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 90% |
| 0.05 | 49 | 0 | 90% |
| 0.10 | 49 | 0 | 90% |
| 0.15 | 48 | 1 | 90% |
| 0.20 | 48 | 1 | 90% |
| 0.25 | 48 | 1 | 90% |
| 0.30 | 48 | 1 | 90% |
| 0.35 | 48 | 1 | 90% |
| 0.40 | 48 | 1 | 90% |
| 0.50 | 48 | 1 | 90% |

### has_most_favored_nation

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 96% · mean margin: 0.967

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 47 | 0.968 | 0.672 – 1.000 |
| `True` | 2 | 0.949 | 0.906 – 0.992 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 96% |
| 0.05 | 49 | 0 | 96% |
| 0.10 | 49 | 0 | 96% |
| 0.15 | 49 | 0 | 96% |
| 0.20 | 49 | 0 | 96% |
| 0.25 | 49 | 0 | 96% |
| 0.30 | 49 | 0 | 96% |
| 0.35 | 49 | 0 | 96% |
| 0.40 | 49 | 0 | 96% |
| 0.50 | 49 | 0 | 96% |

### governing_law

- role: `ENUM12` · abstain target: `not_specified` · n: 49 · baseline acc: 29% · mean margin: 0.513

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `California` | 4 | 0.503 | 0.172 – 0.825 |
| `Delaware` | 8 | 0.383 | 0.000 – 0.978 |
| `Florida` | 1 | 0.215 | 0.215 – 0.215 |
| `Illinois` | 2 | 0.529 | 0.238 – 0.819 |
| `Nevada` | 1 | 0.885 | 0.885 – 0.885 |
| `New York` | 8 | 0.487 | 0.168 – 0.886 |
| `Pennsylvania` | 2 | 0.316 | 0.000 – 0.632 |
| `People's Republic of China` | 1 | 0.449 | 0.449 – 0.449 |
| `Texas` | 2 | 0.624 | 0.527 – 0.721 |
| `not_specified` | 5 | 0.935 | 0.781 – 1.000 |
| `other` | 15 | 0.466 | 0.062 – 0.932 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 44 | 20% | 20% | 0% |
| 0.05 | 47 | 2 | 42 | 21% | 20% | 0% |
| 0.10 | 44 | 5 | 39 | 15% | 14% | 0% |
| 0.15 | 42 | 7 | 37 | 16% | 14% | 0% |
| 0.20 | 38 | 11 | 33 | 18% | 14% | 0% |
| 0.25 | 34 | 15 | 29 | 21% | 14% | 0% |
| 0.30 | 33 | 16 | 28 | 21% | 14% | 0% |
| 0.35 | 32 | 17 | 27 | 19% | 11% | 0% |
| 0.40 | 29 | 20 | 24 | 21% | 11% | 0% |
| 0.50 | 25 | 24 | 20 | 25% | 11% | 0% |

### renewal_term

- role: `ENUM6` · abstain target: `not_specified` · n: 49 · baseline acc: 69% · mean margin: 0.627

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `fixed_term` | 6 | 0.649 | 0.476 – 0.822 |
| `not_specified` | 34 | 0.630 | 0.115 – 0.999 |
| `perpetual` | 1 | 0.662 | 0.662 – 0.662 |
| `successive_1_year` | 7 | 0.561 | 0.289 – 0.801 |
| `successive_multi_year` | 1 | 0.852 | 0.852 – 0.852 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.05 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.10 | 49 | 0 | 15 | 7% | 7% | 0% |
| 0.15 | 47 | 2 | 15 | 7% | 7% | 6% |
| 0.20 | 46 | 3 | 15 | 7% | 7% | 9% |
| 0.25 | 46 | 3 | 15 | 7% | 7% | 9% |
| 0.30 | 45 | 4 | 14 | 7% | 7% | 9% |
| 0.35 | 43 | 6 | 14 | 7% | 7% | 15% |
| 0.40 | 42 | 7 | 13 | 8% | 7% | 15% |
| 0.50 | 36 | 13 | 11 | 9% | 7% | 26% |

### expiration_type

- role: `ENUM3` · abstain target: `not_specified` · n: 49 · baseline acc: 45% · mean margin: 0.551

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `not_specified` | 21 | 0.539 | 0.055 – 1.000 |
| `perpetual` | 6 | 0.615 | 0.240 – 0.748 |
| `specific_date` | 22 | 0.545 | 0.000 – 0.932 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 28 | 68% | 68% | 0% |
| 0.05 | 48 | 1 | 27 | 67% | 64% | 0% |
| 0.10 | 46 | 3 | 26 | 69% | 64% | 5% |
| 0.15 | 44 | 5 | 25 | 68% | 61% | 10% |
| 0.20 | 42 | 7 | 24 | 67% | 57% | 14% |
| 0.25 | 41 | 8 | 23 | 70% | 57% | 14% |
| 0.30 | 36 | 13 | 21 | 67% | 50% | 29% |
| 0.35 | 36 | 13 | 21 | 67% | 50% | 29% |
| 0.40 | 33 | 16 | 20 | 65% | 46% | 38% |
| 0.50 | 29 | 20 | 18 | 67% | 43% | 48% |

