## restaurants_qwen7b

- **Schema:** `data/Restaurants_1_schema.json`
- **Data:** `data/Restaurants_1_test.jsonl`
- **Model:** `_`
- **Fields gated (5):** `serves_alcohol`, `has_live_music`, `party_size`, `price_range`, `cuisine`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `serves_alcohol` | BOOL | — | 50 | 50% | 0.819 |
| `has_live_music` | BOOL | — | 50 | 96% | 0.999 |
| `party_size` | ENUM6 | — | 25 | 100% | 0.983 |
| `price_range` | ENUM4 | — | 50 | 64% | 0.679 |
| `cuisine` | ENUM5 | — | 50 | 36% | 0.856 |

### serves_alcohol

- role: `BOOL` · abstain target: none · n: 50 · baseline acc: 50% · mean margin: 0.819

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 34 | 0.776 | 0.000 – 1.000 |
| `True` | 16 | 0.911 | 0.244 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 50% |
| 0.05 | 49 | 1 | 51% |
| 0.10 | 47 | 3 | 51% |
| 0.15 | 47 | 3 | 51% |
| 0.20 | 46 | 4 | 52% |
| 0.25 | 44 | 6 | 52% |
| 0.30 | 44 | 6 | 52% |
| 0.35 | 44 | 6 | 52% |
| 0.40 | 43 | 7 | 51% |
| 0.50 | 42 | 8 | 52% |

### has_live_music

- role: `BOOL` · abstain target: none · n: 50 · baseline acc: 96% · mean margin: 0.999

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 46 | 1.000 | 0.991 – 1.000 |
| `True` | 4 | 0.997 | 0.991 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 96% |
| 0.05 | 50 | 0 | 96% |
| 0.10 | 50 | 0 | 96% |
| 0.15 | 50 | 0 | 96% |
| 0.20 | 50 | 0 | 96% |
| 0.25 | 50 | 0 | 96% |
| 0.30 | 50 | 0 | 96% |
| 0.35 | 50 | 0 | 96% |
| 0.40 | 50 | 0 | 96% |
| 0.50 | 50 | 0 | 96% |

### party_size

- role: `ENUM6` · abstain target: none · n: 25 · baseline acc: 100% · mean margin: 0.983

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `1` | 3 | 0.999 | 0.999 – 1.000 |
| `2` | 16 | 0.974 | 0.590 – 1.000 |
| `3` | 3 | 1.000 | 1.000 – 1.000 |
| `4` | 3 | 0.998 | 0.994 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 25 | 0 | 100% |
| 0.05 | 25 | 0 | 100% |
| 0.10 | 25 | 0 | 100% |
| 0.15 | 25 | 0 | 100% |
| 0.20 | 25 | 0 | 100% |
| 0.25 | 25 | 0 | 100% |
| 0.30 | 25 | 0 | 100% |
| 0.35 | 25 | 0 | 100% |
| 0.40 | 25 | 0 | 100% |
| 0.50 | 25 | 0 | 100% |

### price_range

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 64% · mean margin: 0.679

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `expensive` | 5 | 0.629 | 0.305 – 0.961 |
| `inexpensive` | 8 | 0.789 | 0.266 – 1.000 |
| `moderate` | 36 | 0.654 | 0.236 – 1.000 |
| `very expensive` | 1 | 0.976 | 0.976 – 0.976 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 64% |
| 0.05 | 50 | 0 | 64% |
| 0.10 | 50 | 0 | 64% |
| 0.15 | 50 | 0 | 64% |
| 0.20 | 50 | 0 | 64% |
| 0.25 | 49 | 1 | 65% |
| 0.30 | 48 | 2 | 67% |
| 0.35 | 44 | 6 | 68% |
| 0.40 | 43 | 7 | 70% |
| 0.50 | 36 | 14 | 67% |

### cuisine

- role: `ENUM5` · abstain target: none · n: 50 · baseline acc: 36% · mean margin: 0.856

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `American` | 3 | 1.000 | 0.999 – 1.000 |
| `Breakfast` | 3 | 1.000 | 1.000 – 1.000 |
| `Brunch` | 1 | 0.412 | 0.412 – 0.412 |
| `Chinese` | 6 | 0.984 | 0.906 – 1.000 |
| `Filipino` | 1 | 0.890 | 0.890 – 0.890 |
| `French` | 1 | 0.961 | 0.961 – 0.961 |
| `Indian` | 3 | 1.000 | 1.000 – 1.000 |
| `Italian` | 5 | 0.996 | 0.991 – 1.000 |
| `Japanese` | 9 | 0.585 | 0.061 – 0.966 |
| `Korean` | 1 | 0.898 | 0.898 – 0.898 |
| `Mexican` | 1 | 1.000 | 1.000 – 1.000 |
| `Pakistani` | 1 | 0.986 | 0.986 – 0.986 |
| `Russian` | 1 | 0.920 | 0.920 – 0.920 |
| `Salad` | 1 | 0.979 | 0.979 – 0.979 |
| `Seafood` | 4 | 0.847 | 0.672 – 1.000 |
| `Spanish` | 1 | 0.984 | 0.984 – 0.984 |
| `Steakhouse` | 1 | 1.000 | 1.000 – 1.000 |
| `Sushi` | 1 | 0.355 | 0.355 – 0.355 |
| `Take-out` | 5 | 0.905 | 0.634 – 1.000 |
| `Thai` | 1 | 0.363 | 0.363 – 0.363 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 36% |
| 0.05 | 50 | 0 | 36% |
| 0.10 | 48 | 2 | 38% |
| 0.15 | 48 | 2 | 38% |
| 0.20 | 48 | 2 | 38% |
| 0.25 | 48 | 2 | 38% |
| 0.30 | 48 | 2 | 38% |
| 0.35 | 47 | 3 | 38% |
| 0.40 | 45 | 5 | 40% |
| 0.50 | 44 | 6 | 41% |

