## flights_qwen7b_pcl

- **Schema:** `data/Flights_1_schema_pcl.json`
- **Data:** `data/Flights_1_test_pcl.jsonl`
- **Model:** `_`
- **Fields gated (5):** `passengers`, `seating_class`, `number_stops`, `refundable`, `airlines`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `passengers` | ENUM4 | — | 50 | 98% | 0.980 |
| `seating_class` | ENUM4 | — | 50 | 100% | 0.984 |
| `number_stops` | ENUM2 | — | 50 | 66% | 0.666 |
| `refundable` | ENUM3 | `ambiguous` | 50 | 100% | 0.979 |
| `airlines` | ENUM8 | — | 50 | 88% | 0.820 |

### passengers

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 98% · mean margin: 0.980

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `1` | 32 | 0.999 | 0.965 – 1.000 |
| `2` | 7 | 1.000 | 1.000 – 1.000 |
| `3` | 5 | 1.000 | 1.000 – 1.000 |
| `4` | 6 | 0.844 | 0.062 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 98% |
| 0.05 | 50 | 0 | 98% |
| 0.10 | 49 | 1 | 100% |
| 0.15 | 49 | 1 | 100% |
| 0.20 | 49 | 1 | 100% |
| 0.25 | 49 | 1 | 100% |
| 0.30 | 49 | 1 | 100% |
| 0.35 | 49 | 1 | 100% |
| 0.40 | 49 | 1 | 100% |
| 0.50 | 49 | 1 | 100% |

### seating_class

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 100% · mean margin: 0.984

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Economy` | 44 | 0.982 | 0.646 – 1.000 |
| `Premium Economy` | 6 | 1.000 | 1.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 100% |
| 0.05 | 50 | 0 | 100% |
| 0.10 | 50 | 0 | 100% |
| 0.15 | 50 | 0 | 100% |
| 0.20 | 50 | 0 | 100% |
| 0.25 | 50 | 0 | 100% |
| 0.30 | 50 | 0 | 100% |
| 0.35 | 50 | 0 | 100% |
| 0.40 | 50 | 0 | 100% |
| 0.50 | 50 | 0 | 100% |

### number_stops

- role: `ENUM2` · abstain target: none · n: 50 · baseline acc: 66% · mean margin: 0.666

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `0` | 27 | 0.724 | 0.062 – 0.999 |
| `1` | 23 | 0.599 | 0.062 – 0.999 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 66% |
| 0.05 | 50 | 0 | 66% |
| 0.10 | 47 | 3 | 70% |
| 0.15 | 47 | 3 | 70% |
| 0.20 | 44 | 6 | 73% |
| 0.25 | 41 | 9 | 73% |
| 0.30 | 41 | 9 | 73% |
| 0.35 | 38 | 12 | 74% |
| 0.40 | 36 | 14 | 78% |
| 0.50 | 35 | 15 | 77% |

### refundable

- role: `ENUM3` · abstain target: `ambiguous` · n: 50 · baseline acc: 100% · mean margin: 0.979

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 9 | 0.900 | 0.270 – 1.000 |
| `True` | 5 | 0.968 | 0.850 – 1.000 |
| `ambiguous` | 36 | 1.000 | 1.000 – 1.000 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_ambiguous`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.05 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.10 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.15 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.20 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.25 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.30 | 49 | 1 | 13 | 100% | 93% | 0% |
| 0.35 | 49 | 1 | 13 | 100% | 93% | 0% |
| 0.40 | 49 | 1 | 13 | 100% | 93% | 0% |
| 0.50 | 49 | 1 | 13 | 100% | 93% | 0% |

### airlines

- role: `ENUM8` · abstain target: none · n: 50 · baseline acc: 88% · mean margin: 0.820

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Air Canada` | 2 | 0.422 | 0.345 – 0.500 |
| `Alaska Airlines` | 5 | 0.860 | 0.552 – 1.000 |
| `American Airlines` | 22 | 0.707 | 0.000 – 1.000 |
| `Delta Airlines` | 10 | 0.945 | 0.449 – 1.000 |
| `Southwest Airlines` | 5 | 0.999 | 0.995 – 1.000 |
| `United Airlines` | 6 | 0.979 | 0.881 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 88% |
| 0.05 | 49 | 1 | 88% |
| 0.10 | 48 | 2 | 88% |
| 0.15 | 47 | 3 | 87% |
| 0.20 | 47 | 3 | 87% |
| 0.25 | 45 | 5 | 89% |
| 0.30 | 45 | 5 | 89% |
| 0.35 | 44 | 6 | 91% |
| 0.40 | 44 | 6 | 91% |
| 0.50 | 40 | 10 | 98% |

