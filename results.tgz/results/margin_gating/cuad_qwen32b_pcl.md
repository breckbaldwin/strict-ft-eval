## cuad_qwen32b_pcl

- **Schema:** `data/cuad_schema.json`
- **Data:** `data/cuad_test.jsonl`
- **Model:** `_`
- **Fields gated (11):** `has_anti_assignment`, `has_cap_on_liability`, `has_audit_rights`, `has_exclusivity`, `has_change_of_control`, `has_non_compete`, `has_liquidated_damages`, `has_most_favored_nation`, `governing_law`, `renewal_term`, `expiration_type`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `has_anti_assignment` | BOOL | — | 49 | 86% | 0.882 |
| `has_cap_on_liability` | BOOL | — | 49 | 71% | 0.766 |
| `has_audit_rights` | BOOL | — | 49 | 78% | 0.807 |
| `has_exclusivity` | BOOL | — | 49 | 94% | 0.915 |
| `has_change_of_control` | BOOL | — | 49 | 82% | 0.940 |
| `has_non_compete` | BOOL | — | 49 | 76% | 0.808 |
| `has_liquidated_damages` | BOOL | — | 49 | 90% | 0.967 |
| `has_most_favored_nation` | BOOL | — | 49 | 96% | 0.975 |
| `governing_law` | ENUM12 | `not_specified` | 49 | 53% | 0.625 |
| `renewal_term` | ENUM6 | `not_specified` | 49 | 65% | 0.803 |
| `expiration_type` | ENUM3 | `not_specified` | 49 | 49% | 0.515 |

### has_anti_assignment

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 86% · mean margin: 0.882

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 11 | 0.894 | 0.412 – 1.000 |
| `True` | 38 | 0.878 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 86% |
| 0.05 | 48 | 1 | 85% |
| 0.10 | 48 | 1 | 85% |
| 0.15 | 48 | 1 | 85% |
| 0.20 | 48 | 1 | 85% |
| 0.25 | 47 | 2 | 87% |
| 0.30 | 47 | 2 | 87% |
| 0.35 | 47 | 2 | 87% |
| 0.40 | 47 | 2 | 87% |
| 0.50 | 45 | 4 | 87% |

### has_cap_on_liability

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 71% · mean margin: 0.766

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 23 | 0.741 | 0.000 – 1.000 |
| `True` | 26 | 0.789 | 0.244 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 71% |
| 0.05 | 47 | 2 | 74% |
| 0.10 | 47 | 2 | 74% |
| 0.15 | 46 | 3 | 74% |
| 0.20 | 46 | 3 | 74% |
| 0.25 | 44 | 5 | 75% |
| 0.30 | 44 | 5 | 75% |
| 0.35 | 43 | 6 | 74% |
| 0.40 | 42 | 7 | 76% |
| 0.50 | 40 | 9 | 78% |

### has_audit_rights

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 78% · mean margin: 0.807

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 24 | 0.841 | 0.062 – 1.000 |
| `True` | 25 | 0.774 | 0.062 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 78% |
| 0.05 | 49 | 0 | 78% |
| 0.10 | 46 | 3 | 83% |
| 0.15 | 46 | 3 | 83% |
| 0.20 | 45 | 4 | 84% |
| 0.25 | 43 | 6 | 88% |
| 0.30 | 43 | 6 | 88% |
| 0.35 | 43 | 6 | 88% |
| 0.40 | 43 | 6 | 88% |
| 0.50 | 42 | 7 | 88% |

### has_exclusivity

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 94% · mean margin: 0.915

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 32 | 0.975 | 0.788 – 1.000 |
| `True` | 17 | 0.803 | 0.186 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 94% |
| 0.05 | 49 | 0 | 94% |
| 0.10 | 49 | 0 | 94% |
| 0.15 | 49 | 0 | 94% |
| 0.20 | 48 | 1 | 94% |
| 0.25 | 48 | 1 | 94% |
| 0.30 | 48 | 1 | 94% |
| 0.35 | 48 | 1 | 94% |
| 0.40 | 47 | 2 | 94% |
| 0.50 | 47 | 2 | 94% |

### has_change_of_control

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 82% · mean margin: 0.940

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 40 | 0.953 | 0.244 – 1.000 |
| `True` | 9 | 0.883 | 0.186 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 82% |
| 0.05 | 49 | 0 | 82% |
| 0.10 | 49 | 0 | 82% |
| 0.15 | 49 | 0 | 82% |
| 0.20 | 48 | 1 | 83% |
| 0.25 | 47 | 2 | 83% |
| 0.30 | 47 | 2 | 83% |
| 0.35 | 47 | 2 | 83% |
| 0.40 | 47 | 2 | 83% |
| 0.50 | 46 | 3 | 85% |

### has_non_compete

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 76% · mean margin: 0.808

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 39 | 0.816 | 0.125 – 1.000 |
| `True` | 10 | 0.776 | 0.303 – 0.998 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 76% |
| 0.05 | 49 | 0 | 76% |
| 0.10 | 49 | 0 | 76% |
| 0.15 | 47 | 2 | 79% |
| 0.20 | 46 | 3 | 80% |
| 0.25 | 46 | 3 | 80% |
| 0.30 | 46 | 3 | 80% |
| 0.35 | 45 | 4 | 80% |
| 0.40 | 42 | 7 | 79% |
| 0.50 | 40 | 9 | 82% |

### has_liquidated_damages

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 90% · mean margin: 0.967

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 44 | 0.975 | 0.829 – 1.000 |
| `True` | 5 | 0.893 | 0.703 – 0.986 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 90% |
| 0.05 | 49 | 0 | 90% |
| 0.10 | 49 | 0 | 90% |
| 0.15 | 49 | 0 | 90% |
| 0.20 | 49 | 0 | 90% |
| 0.25 | 49 | 0 | 90% |
| 0.30 | 49 | 0 | 90% |
| 0.35 | 49 | 0 | 90% |
| 0.40 | 49 | 0 | 90% |
| 0.50 | 49 | 0 | 90% |

### has_most_favored_nation

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 96% · mean margin: 0.975

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 47 | 0.976 | 0.303 – 1.000 |
| `True` | 2 | 0.941 | 0.881 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 96% |
| 0.05 | 49 | 0 | 96% |
| 0.10 | 49 | 0 | 96% |
| 0.15 | 49 | 0 | 96% |
| 0.20 | 49 | 0 | 96% |
| 0.25 | 49 | 0 | 96% |
| 0.30 | 49 | 0 | 96% |
| 0.35 | 48 | 1 | 98% |
| 0.40 | 48 | 1 | 98% |
| 0.50 | 48 | 1 | 98% |

### governing_law

- role: `ENUM12` · abstain target: `not_specified` · n: 49 · baseline acc: 53% · mean margin: 0.625

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `California` | 4 | 0.709 | 0.521 – 0.995 |
| `Delaware` | 8 | 0.581 | 0.078 – 0.920 |
| `Florida` | 1 | 0.399 | 0.399 – 0.399 |
| `Illinois` | 2 | 0.862 | 0.729 – 0.995 |
| `Nevada` | 1 | 0.517 | 0.517 – 0.517 |
| `New York` | 8 | 0.531 | 0.082 – 0.973 |
| `Pennsylvania` | 2 | 0.501 | 0.256 – 0.746 |
| `People's Republic of China` | 1 | 0.995 | 0.995 – 0.995 |
| `Texas` | 2 | 0.738 | 0.476 – 1.000 |
| `not_specified` | 5 | 0.832 | 0.162 – 1.000 |
| `other` | 15 | 0.574 | 0.049 – 1.000 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 44 | 48% | 48% | 0% |
| 0.05 | 48 | 1 | 43 | 47% | 45% | 0% |
| 0.10 | 46 | 3 | 41 | 46% | 43% | 0% |
| 0.15 | 43 | 6 | 38 | 47% | 41% | 0% |
| 0.20 | 42 | 7 | 38 | 47% | 41% | 20% |
| 0.25 | 39 | 10 | 35 | 49% | 39% | 20% |
| 0.30 | 36 | 13 | 32 | 50% | 36% | 20% |
| 0.35 | 36 | 13 | 32 | 50% | 36% | 20% |
| 0.40 | 34 | 15 | 30 | 47% | 32% | 20% |
| 0.50 | 33 | 16 | 29 | 45% | 30% | 20% |

### renewal_term

- role: `ENUM6` · abstain target: `not_specified` · n: 49 · baseline acc: 65% · mean margin: 0.803

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `fixed_term` | 6 | 0.700 | 0.423 – 0.916 |
| `not_specified` | 34 | 0.859 | 0.169 – 1.000 |
| `perpetual` | 1 | 0.681 | 0.681 – 0.681 |
| `successive_1_year` | 7 | 0.617 | 0.328 – 0.835 |
| `successive_multi_year` | 1 | 0.968 | 0.968 – 0.968 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 15 | 0% | 0% | 0% |
| 0.05 | 49 | 0 | 15 | 0% | 0% | 0% |
| 0.10 | 49 | 0 | 15 | 0% | 0% | 0% |
| 0.15 | 49 | 0 | 15 | 0% | 0% | 0% |
| 0.20 | 48 | 1 | 15 | 0% | 0% | 3% |
| 0.25 | 48 | 1 | 15 | 0% | 0% | 3% |
| 0.30 | 47 | 2 | 15 | 0% | 0% | 6% |
| 0.35 | 46 | 3 | 14 | 0% | 0% | 6% |
| 0.40 | 45 | 4 | 14 | 0% | 0% | 9% |
| 0.50 | 39 | 10 | 10 | 0% | 0% | 15% |

### expiration_type

- role: `ENUM3` · abstain target: `not_specified` · n: 49 · baseline acc: 49% · mean margin: 0.515

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `not_specified` | 21 | 0.527 | 0.000 – 1.000 |
| `perpetual` | 6 | 0.677 | 0.119 – 0.940 |
| `specific_date` | 22 | 0.460 | 0.000 – 1.000 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 28 | 39% | 39% | 0% |
| 0.05 | 44 | 5 | 24 | 46% | 39% | 5% |
| 0.10 | 44 | 5 | 24 | 46% | 39% | 5% |
| 0.15 | 39 | 10 | 22 | 45% | 36% | 19% |
| 0.20 | 38 | 11 | 21 | 48% | 36% | 19% |
| 0.25 | 34 | 15 | 18 | 50% | 32% | 24% |
| 0.30 | 32 | 17 | 17 | 47% | 29% | 29% |
| 0.35 | 27 | 22 | 15 | 53% | 29% | 43% |
| 0.40 | 24 | 25 | 13 | 62% | 29% | 48% |
| 0.50 | 21 | 28 | 11 | 73% | 29% | 52% |

