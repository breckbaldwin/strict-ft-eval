## flights_qwen7b

- **Schema:** `data/Flights_1_schema_pcl.json`
- **Data:** `data/Flights_1_test_pcl.jsonl`
- **Model:** `_`
- **Fields gated (5):** `passengers`, `seating_class`, `number_stops`, `refundable`, `airlines`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `passengers` | ENUM4 | — | 50 | 96% | 0.970 |
| `seating_class` | ENUM4 | — | 50 | 100% | 0.974 |
| `number_stops` | ENUM2 | — | 50 | 66% | 0.985 |
| `refundable` | ENUM3 | `ambiguous` | 50 | 26% | 0.795 |
| `airlines` | ENUM8 | — | 50 | 66% | 0.739 |

### passengers

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 96% · mean margin: 0.970

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `1` | 32 | 0.956 | 0.410 – 1.000 |
| `2` | 7 | 0.993 | 0.960 – 1.000 |
| `3` | 5 | 1.000 | 1.000 – 1.000 |
| `4` | 6 | 0.994 | 0.979 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 96% |
| 0.05 | 50 | 0 | 96% |
| 0.10 | 50 | 0 | 96% |
| 0.15 | 50 | 0 | 96% |
| 0.20 | 50 | 0 | 96% |
| 0.25 | 50 | 0 | 96% |
| 0.30 | 50 | 0 | 96% |
| 0.35 | 50 | 0 | 96% |
| 0.40 | 50 | 0 | 96% |
| 0.50 | 49 | 1 | 98% |

### seating_class

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 100% · mean margin: 0.974

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Economy` | 44 | 0.971 | 0.704 – 1.000 |
| `Premium Economy` | 6 | 1.000 | 1.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 100% |
| 0.05 | 50 | 0 | 100% |
| 0.10 | 50 | 0 | 100% |
| 0.15 | 50 | 0 | 100% |
| 0.20 | 50 | 0 | 100% |
| 0.25 | 50 | 0 | 100% |
| 0.30 | 50 | 0 | 100% |
| 0.35 | 50 | 0 | 100% |
| 0.40 | 50 | 0 | 100% |
| 0.50 | 50 | 0 | 100% |

### number_stops

- role: `ENUM2` · abstain target: none · n: 50 · baseline acc: 66% · mean margin: 0.985

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `0` | 27 | 0.995 | 0.976 – 1.000 |
| `1` | 23 | 0.972 | 0.672 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 66% |
| 0.05 | 50 | 0 | 66% |
| 0.10 | 50 | 0 | 66% |
| 0.15 | 50 | 0 | 66% |
| 0.20 | 50 | 0 | 66% |
| 0.25 | 50 | 0 | 66% |
| 0.30 | 50 | 0 | 66% |
| 0.35 | 50 | 0 | 66% |
| 0.40 | 50 | 0 | 66% |
| 0.50 | 50 | 0 | 66% |

### refundable

- role: `ENUM3` · abstain target: `ambiguous` · n: 50 · baseline acc: 26% · mean margin: 0.795

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 9 | 0.977 | 0.915 – 1.000 |
| `True` | 5 | 0.635 | 0.000 – 0.999 |
| `ambiguous` | 36 | 0.772 | 0.634 – 0.976 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_ambiguous`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 14 | 93% | 93% | 0% |
| 0.05 | 49 | 1 | 13 | 92% | 86% | 0% |
| 0.10 | 49 | 1 | 13 | 92% | 86% | 0% |
| 0.15 | 49 | 1 | 13 | 92% | 86% | 0% |
| 0.20 | 49 | 1 | 13 | 92% | 86% | 0% |
| 0.25 | 49 | 1 | 13 | 92% | 86% | 0% |
| 0.30 | 49 | 1 | 13 | 92% | 86% | 0% |
| 0.35 | 49 | 1 | 13 | 92% | 86% | 0% |
| 0.40 | 49 | 1 | 13 | 92% | 86% | 0% |
| 0.50 | 48 | 2 | 12 | 100% | 86% | 0% |

### airlines

- role: `ENUM8` · abstain target: none · n: 50 · baseline acc: 66% · mean margin: 0.739

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Air Canada` | 2 | 0.587 | 0.500 – 0.675 |
| `Alaska Airlines` | 5 | 0.688 | 0.109 – 1.000 |
| `American Airlines` | 22 | 0.597 | 0.041 – 1.000 |
| `Delta Airlines` | 10 | 0.896 | 0.045 – 1.000 |
| `Southwest Airlines` | 5 | 1.000 | 1.000 – 1.000 |
| `United Airlines` | 6 | 0.870 | 0.221 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 66% |
| 0.05 | 48 | 2 | 67% |
| 0.10 | 47 | 3 | 66% |
| 0.15 | 46 | 4 | 67% |
| 0.20 | 45 | 5 | 69% |
| 0.25 | 41 | 9 | 73% |
| 0.30 | 40 | 10 | 75% |
| 0.35 | 40 | 10 | 75% |
| 0.40 | 37 | 13 | 81% |
| 0.50 | 34 | 16 | 88% |

