## flights_qwen05b_pcl

- **Schema:** `data/Flights_1_schema_pcl.json`
- **Data:** `data/Flights_1_test_pcl.jsonl`
- **Model:** `_`
- **Fields gated (5):** `passengers`, `seating_class`, `number_stops`, `refundable`, `airlines`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `passengers` | ENUM4 | — | 50 | 98% | 0.971 |
| `seating_class` | ENUM4 | — | 50 | 100% | 0.990 |
| `number_stops` | ENUM2 | — | 50 | 62% | 0.414 |
| `refundable` | ENUM3 | `ambiguous` | 50 | 100% | 0.962 |
| `airlines` | ENUM8 | — | 50 | 88% | 0.750 |

### passengers

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 98% · mean margin: 0.971

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `1` | 32 | 0.974 | 0.305 – 1.000 |
| `2` | 7 | 0.944 | 0.634 – 1.000 |
| `3` | 5 | 1.000 | 1.000 – 1.000 |
| `4` | 6 | 0.961 | 0.829 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 98% |
| 0.05 | 50 | 0 | 98% |
| 0.10 | 50 | 0 | 98% |
| 0.15 | 50 | 0 | 98% |
| 0.20 | 50 | 0 | 98% |
| 0.25 | 50 | 0 | 98% |
| 0.30 | 50 | 0 | 98% |
| 0.35 | 49 | 1 | 98% |
| 0.40 | 49 | 1 | 98% |
| 0.50 | 49 | 1 | 98% |

### seating_class

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 100% · mean margin: 0.990

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Economy` | 44 | 0.994 | 0.750 – 1.000 |
| `Premium Economy` | 6 | 0.965 | 0.843 – 0.998 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 100% |
| 0.05 | 50 | 0 | 100% |
| 0.10 | 50 | 0 | 100% |
| 0.15 | 50 | 0 | 100% |
| 0.20 | 50 | 0 | 100% |
| 0.25 | 50 | 0 | 100% |
| 0.30 | 50 | 0 | 100% |
| 0.35 | 50 | 0 | 100% |
| 0.40 | 50 | 0 | 100% |
| 0.50 | 50 | 0 | 100% |

### number_stops

- role: `ENUM2` · abstain target: none · n: 50 · baseline acc: 62% · mean margin: 0.414

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `0` | 27 | 0.401 | 0.000 – 1.000 |
| `1` | 23 | 0.430 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 62% |
| 0.05 | 45 | 5 | 62% |
| 0.10 | 39 | 11 | 64% |
| 0.15 | 33 | 17 | 70% |
| 0.20 | 25 | 25 | 76% |
| 0.25 | 22 | 28 | 82% |
| 0.30 | 22 | 28 | 82% |
| 0.35 | 18 | 32 | 89% |
| 0.40 | 17 | 33 | 94% |
| 0.50 | 17 | 33 | 94% |

### refundable

- role: `ENUM3` · abstain target: `ambiguous` · n: 50 · baseline acc: 100% · mean margin: 0.962

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 9 | 0.862 | 0.595 – 1.000 |
| `True` | 5 | 0.896 | 0.555 – 0.994 |
| `ambiguous` | 36 | 0.996 | 0.939 – 1.000 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_ambiguous`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.05 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.10 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.15 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.20 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.25 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.30 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.35 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.40 | 50 | 0 | 14 | 100% | 100% | 0% |
| 0.50 | 50 | 0 | 14 | 100% | 100% | 0% |

### airlines

- role: `ENUM8` · abstain target: none · n: 50 · baseline acc: 88% · mean margin: 0.750

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Air Canada` | 2 | 0.466 | 0.433 – 0.499 |
| `Alaska Airlines` | 5 | 0.759 | 0.225 – 1.000 |
| `American Airlines` | 22 | 0.593 | 0.109 – 1.000 |
| `Delta Airlines` | 10 | 0.921 | 0.279 – 1.000 |
| `Southwest Airlines` | 5 | 0.995 | 0.975 – 1.000 |
| `United Airlines` | 6 | 0.929 | 0.580 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 88% |
| 0.05 | 50 | 0 | 88% |
| 0.10 | 50 | 0 | 88% |
| 0.15 | 48 | 2 | 88% |
| 0.20 | 47 | 3 | 89% |
| 0.25 | 45 | 5 | 91% |
| 0.30 | 42 | 8 | 93% |
| 0.35 | 38 | 12 | 92% |
| 0.40 | 38 | 12 | 92% |
| 0.50 | 35 | 15 | 97% |

