## flights_qwen05b

- **Schema:** `/Users/bb/forgejo/PCL/data/Flights_1_schema_pcl.json`
- **Data:** `/Users/bb/forgejo/PCL/data/Flights_1_test_pcl.jsonl`
- **Model:** `Qwen/Qwen2.5-0.5B-Instruct`
- **Fields gated (1):** `refundable`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `refundable` | ENUM3 | `ambiguous` | 50 | 12% | 0.255 |

### refundable

- role: `ENUM3` · abstain target: `ambiguous` · n: 50 · baseline acc: 12% · mean margin: 0.255

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 9 | 0.225 | 0.008 – 0.624 |
| `True` | 5 | 0.686 | 0.583 – 0.784 |
| `ambiguous` | 36 | 0.202 | 0.022 – 0.335 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_ambiguous`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 14 | 43% | 43% | 0% |
| 0.05 | 47 | 3 | 13 | 46% | 43% | 6% |
| 0.10 | 44 | 6 | 11 | 45% | 36% | 8% |
| 0.15 | 37 | 13 | 10 | 50% | 36% | 25% |
| 0.20 | 28 | 22 | 9 | 56% | 36% | 47% |
| 0.25 | 19 | 31 | 8 | 62% | 36% | 69% |
| 0.30 | 12 | 38 | 7 | 71% | 36% | 86% |
| 0.35 | 7 | 43 | 7 | 71% | 36% | 100% |
| 0.40 | 7 | 43 | 7 | 71% | 36% | 100% |
| 0.50 | 7 | 43 | 7 | 71% | 36% | 100% |

