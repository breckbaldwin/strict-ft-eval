## restaurants_qwen32b

- **Schema:** `data/Restaurants_1_schema.json`
- **Data:** `data/Restaurants_1_test.jsonl`
- **Model:** `_`
- **Fields gated (5):** `serves_alcohol`, `has_live_music`, `party_size`, `price_range`, `cuisine`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `serves_alcohol` | BOOL | — | 50 | 56% | 0.669 |
| `has_live_music` | BOOL | — | 50 | 96% | 0.998 |
| `party_size` | ENUM6 | — | 25 | 100% | 0.997 |
| `price_range` | ENUM4 | — | 50 | 74% | 0.681 |
| `cuisine` | ENUM5 | — | 50 | 36% | 0.876 |

### serves_alcohol

- role: `BOOL` · abstain target: none · n: 50 · baseline acc: 56% · mean margin: 0.669

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 34 | 0.591 | 0.000 – 1.000 |
| `True` | 16 | 0.833 | 0.461 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 56% |
| 0.05 | 49 | 1 | 57% |
| 0.10 | 48 | 2 | 58% |
| 0.15 | 48 | 2 | 58% |
| 0.20 | 48 | 2 | 58% |
| 0.25 | 42 | 8 | 52% |
| 0.30 | 42 | 8 | 52% |
| 0.35 | 41 | 9 | 54% |
| 0.40 | 38 | 12 | 58% |
| 0.50 | 34 | 16 | 59% |

### has_live_music

- role: `BOOL` · abstain target: none · n: 50 · baseline acc: 96% · mean margin: 0.998

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 46 | 0.998 | 0.984 – 1.000 |
| `True` | 4 | 0.998 | 0.992 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 96% |
| 0.05 | 50 | 0 | 96% |
| 0.10 | 50 | 0 | 96% |
| 0.15 | 50 | 0 | 96% |
| 0.20 | 50 | 0 | 96% |
| 0.25 | 50 | 0 | 96% |
| 0.30 | 50 | 0 | 96% |
| 0.35 | 50 | 0 | 96% |
| 0.40 | 50 | 0 | 96% |
| 0.50 | 50 | 0 | 96% |

### party_size

- role: `ENUM6` · abstain target: none · n: 25 · baseline acc: 100% · mean margin: 0.997

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `1` | 3 | 1.000 | 1.000 – 1.000 |
| `2` | 16 | 0.995 | 0.960 – 1.000 |
| `3` | 3 | 1.000 | 1.000 – 1.000 |
| `4` | 3 | 1.000 | 0.999 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 25 | 0 | 100% |
| 0.05 | 25 | 0 | 100% |
| 0.10 | 25 | 0 | 100% |
| 0.15 | 25 | 0 | 100% |
| 0.20 | 25 | 0 | 100% |
| 0.25 | 25 | 0 | 100% |
| 0.30 | 25 | 0 | 100% |
| 0.35 | 25 | 0 | 100% |
| 0.40 | 25 | 0 | 100% |
| 0.50 | 25 | 0 | 100% |

### price_range

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 74% · mean margin: 0.681

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `expensive` | 5 | 0.813 | 0.595 – 0.941 |
| `inexpensive` | 8 | 0.751 | 0.475 – 1.000 |
| `moderate` | 36 | 0.650 | 0.000 – 1.000 |
| `very expensive` | 1 | 0.587 | 0.587 – 0.587 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 74% |
| 0.05 | 49 | 1 | 76% |
| 0.10 | 48 | 2 | 75% |
| 0.15 | 47 | 3 | 74% |
| 0.20 | 46 | 4 | 76% |
| 0.25 | 46 | 4 | 76% |
| 0.30 | 44 | 6 | 75% |
| 0.35 | 43 | 7 | 74% |
| 0.40 | 43 | 7 | 74% |
| 0.50 | 37 | 13 | 76% |

### cuisine

- role: `ENUM5` · abstain target: none · n: 50 · baseline acc: 36% · mean margin: 0.876

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `American` | 3 | 1.000 | 1.000 – 1.000 |
| `Breakfast` | 3 | 1.000 | 0.999 – 1.000 |
| `Brunch` | 1 | 0.984 | 0.984 – 0.984 |
| `Chinese` | 6 | 0.996 | 0.986 – 1.000 |
| `Filipino` | 1 | 0.970 | 0.970 – 0.970 |
| `French` | 1 | 0.000 | 0.000 – 0.000 |
| `Indian` | 3 | 1.000 | 1.000 – 1.000 |
| `Italian` | 5 | 0.860 | 0.555 – 1.000 |
| `Japanese` | 9 | 0.763 | 0.301 – 0.987 |
| `Korean` | 1 | 0.404 | 0.404 – 0.404 |
| `Mexican` | 1 | 1.000 | 1.000 – 1.000 |
| `Pakistani` | 1 | 0.979 | 0.979 – 0.979 |
| `Russian` | 1 | 0.960 | 0.960 – 0.960 |
| `Salad` | 1 | 0.994 | 0.994 – 0.994 |
| `Seafood` | 4 | 0.903 | 0.760 – 1.000 |
| `Spanish` | 1 | 0.940 | 0.940 – 0.940 |
| `Steakhouse` | 1 | 1.000 | 1.000 – 1.000 |
| `Sushi` | 1 | 0.999 | 0.999 – 0.999 |
| `Take-out` | 5 | 0.826 | 0.236 – 1.000 |
| `Thai` | 1 | 0.675 | 0.675 – 0.675 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 36% |
| 0.05 | 49 | 1 | 37% |
| 0.10 | 49 | 1 | 37% |
| 0.15 | 49 | 1 | 37% |
| 0.20 | 49 | 1 | 37% |
| 0.25 | 48 | 2 | 38% |
| 0.30 | 48 | 2 | 38% |
| 0.35 | 47 | 3 | 38% |
| 0.40 | 46 | 4 | 39% |
| 0.50 | 45 | 5 | 40% |

