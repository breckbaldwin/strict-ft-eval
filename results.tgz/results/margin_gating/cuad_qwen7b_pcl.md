## cuad_qwen7b_pcl

- **Schema:** `data/cuad_schema.json`
- **Data:** `data/cuad_test.jsonl`
- **Model:** `_`
- **Fields gated (11):** `has_anti_assignment`, `has_cap_on_liability`, `has_audit_rights`, `has_exclusivity`, `has_change_of_control`, `has_non_compete`, `has_liquidated_damages`, `has_most_favored_nation`, `governing_law`, `renewal_term`, `expiration_type`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `has_anti_assignment` | BOOL | — | 49 | 73% | 0.633 |
| `has_cap_on_liability` | BOOL | — | 49 | 71% | 0.944 |
| `has_audit_rights` | BOOL | — | 49 | 78% | 0.854 |
| `has_exclusivity` | BOOL | — | 49 | 76% | 0.777 |
| `has_change_of_control` | BOOL | — | 49 | 80% | 0.700 |
| `has_non_compete` | BOOL | — | 49 | 53% | 0.709 |
| `has_liquidated_damages` | BOOL | — | 49 | 88% | 0.710 |
| `has_most_favored_nation` | BOOL | — | 49 | 98% | 0.954 |
| `governing_law` | ENUM12 | `not_specified` | 49 | 35% | 0.445 |
| `renewal_term` | ENUM6 | `not_specified` | 49 | 43% | 0.439 |
| `expiration_type` | ENUM3 | `not_specified` | 49 | 47% | 0.534 |

### has_anti_assignment

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 73% · mean margin: 0.633

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 11 | 0.599 | 0.186 – 0.936 |
| `True` | 38 | 0.643 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 73% |
| 0.05 | 48 | 1 | 73% |
| 0.10 | 47 | 2 | 74% |
| 0.15 | 45 | 4 | 76% |
| 0.20 | 43 | 6 | 77% |
| 0.25 | 41 | 8 | 78% |
| 0.30 | 41 | 8 | 78% |
| 0.35 | 39 | 10 | 79% |
| 0.40 | 39 | 10 | 79% |
| 0.50 | 31 | 18 | 84% |

### has_cap_on_liability

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 71% · mean margin: 0.944

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 23 | 0.913 | 0.186 – 1.000 |
| `True` | 26 | 0.971 | 0.829 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 71% |
| 0.05 | 49 | 0 | 71% |
| 0.10 | 49 | 0 | 71% |
| 0.15 | 49 | 0 | 71% |
| 0.20 | 48 | 1 | 73% |
| 0.25 | 48 | 1 | 73% |
| 0.30 | 48 | 1 | 73% |
| 0.35 | 48 | 1 | 73% |
| 0.40 | 48 | 1 | 73% |
| 0.50 | 48 | 1 | 73% |

### has_audit_rights

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 78% · mean margin: 0.854

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 24 | 0.795 | 0.186 – 1.000 |
| `True` | 25 | 0.911 | 0.412 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 78% |
| 0.05 | 49 | 0 | 78% |
| 0.10 | 49 | 0 | 78% |
| 0.15 | 49 | 0 | 78% |
| 0.20 | 47 | 2 | 79% |
| 0.25 | 46 | 3 | 80% |
| 0.30 | 46 | 3 | 80% |
| 0.35 | 45 | 4 | 82% |
| 0.40 | 45 | 4 | 82% |
| 0.50 | 40 | 9 | 85% |

### has_exclusivity

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 76% · mean margin: 0.777

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 32 | 0.715 | 0.125 – 1.000 |
| `True` | 17 | 0.895 | 0.125 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 76% |
| 0.05 | 49 | 0 | 76% |
| 0.10 | 49 | 0 | 76% |
| 0.15 | 46 | 3 | 78% |
| 0.20 | 43 | 6 | 79% |
| 0.25 | 43 | 6 | 79% |
| 0.30 | 43 | 6 | 79% |
| 0.35 | 40 | 9 | 80% |
| 0.40 | 40 | 9 | 80% |
| 0.50 | 39 | 10 | 79% |

### has_change_of_control

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 80% · mean margin: 0.700

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 40 | 0.737 | 0.062 – 1.000 |
| `True` | 9 | 0.534 | 0.062 – 0.999 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 80% |
| 0.05 | 49 | 0 | 80% |
| 0.10 | 45 | 4 | 82% |
| 0.15 | 44 | 5 | 84% |
| 0.20 | 43 | 6 | 84% |
| 0.25 | 41 | 8 | 85% |
| 0.30 | 41 | 8 | 85% |
| 0.35 | 37 | 12 | 89% |
| 0.40 | 36 | 13 | 89% |
| 0.50 | 34 | 15 | 88% |

### has_non_compete

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 53% · mean margin: 0.709

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 39 | 0.690 | 0.062 – 1.000 |
| `True` | 10 | 0.783 | 0.186 – 0.992 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 53% |
| 0.05 | 49 | 0 | 53% |
| 0.10 | 48 | 1 | 54% |
| 0.15 | 46 | 3 | 57% |
| 0.20 | 43 | 6 | 58% |
| 0.25 | 42 | 7 | 60% |
| 0.30 | 42 | 7 | 60% |
| 0.35 | 42 | 7 | 60% |
| 0.40 | 40 | 9 | 60% |
| 0.50 | 39 | 10 | 62% |

### has_liquidated_damages

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 88% · mean margin: 0.710

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 44 | 0.738 | 0.000 – 1.000 |
| `True` | 5 | 0.460 | 0.062 – 0.760 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 88% |
| 0.05 | 48 | 1 | 90% |
| 0.10 | 47 | 2 | 91% |
| 0.15 | 46 | 3 | 91% |
| 0.20 | 43 | 6 | 93% |
| 0.25 | 42 | 7 | 93% |
| 0.30 | 42 | 7 | 93% |
| 0.35 | 38 | 11 | 92% |
| 0.40 | 38 | 11 | 92% |
| 0.50 | 36 | 13 | 94% |

### has_most_favored_nation

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 98% · mean margin: 0.954

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 47 | 0.964 | 0.734 – 1.000 |
| `True` | 2 | 0.706 | 0.412 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 98% |
| 0.05 | 49 | 0 | 98% |
| 0.10 | 49 | 0 | 98% |
| 0.15 | 49 | 0 | 98% |
| 0.20 | 49 | 0 | 98% |
| 0.25 | 49 | 0 | 98% |
| 0.30 | 49 | 0 | 98% |
| 0.35 | 49 | 0 | 98% |
| 0.40 | 49 | 0 | 98% |
| 0.50 | 48 | 1 | 98% |

### governing_law

- role: `ENUM12` · abstain target: `not_specified` · n: 49 · baseline acc: 35% · mean margin: 0.445

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `California` | 4 | 0.427 | 0.057 – 0.880 |
| `Delaware` | 8 | 0.421 | 0.105 – 0.913 |
| `Florida` | 1 | 0.000 | 0.000 – 0.000 |
| `Illinois` | 2 | 0.653 | 0.393 – 0.913 |
| `Nevada` | 1 | 0.229 | 0.229 – 0.229 |
| `New York` | 8 | 0.208 | 0.000 – 0.475 |
| `Pennsylvania` | 2 | 0.609 | 0.383 – 0.835 |
| `People's Republic of China` | 1 | 0.505 | 0.505 – 0.505 |
| `Texas` | 2 | 0.541 | 0.170 – 0.911 |
| `not_specified` | 5 | 0.822 | 0.538 – 1.000 |
| `other` | 15 | 0.441 | 0.000 – 0.980 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 44 | 27% | 27% | 0% |
| 0.05 | 45 | 4 | 40 | 25% | 23% | 0% |
| 0.10 | 43 | 6 | 38 | 26% | 23% | 0% |
| 0.15 | 40 | 9 | 35 | 29% | 23% | 0% |
| 0.20 | 34 | 15 | 29 | 34% | 23% | 0% |
| 0.25 | 30 | 19 | 25 | 36% | 20% | 0% |
| 0.30 | 29 | 20 | 24 | 38% | 20% | 0% |
| 0.35 | 28 | 21 | 23 | 39% | 20% | 0% |
| 0.40 | 24 | 25 | 19 | 37% | 16% | 0% |
| 0.50 | 21 | 28 | 16 | 44% | 16% | 0% |

### renewal_term

- role: `ENUM6` · abstain target: `not_specified` · n: 49 · baseline acc: 43% · mean margin: 0.439

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `fixed_term` | 6 | 0.261 | 0.037 – 0.405 |
| `not_specified` | 34 | 0.488 | 0.000 – 1.000 |
| `perpetual` | 1 | 0.587 | 0.587 – 0.587 |
| `successive_1_year` | 7 | 0.281 | 0.000 – 0.473 |
| `successive_multi_year` | 1 | 0.818 | 0.818 – 0.818 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 15 | 13% | 13% | 0% |
| 0.05 | 46 | 3 | 13 | 15% | 13% | 3% |
| 0.10 | 42 | 7 | 13 | 15% | 13% | 15% |
| 0.15 | 38 | 11 | 13 | 15% | 13% | 26% |
| 0.20 | 34 | 15 | 10 | 20% | 13% | 29% |
| 0.25 | 33 | 16 | 10 | 20% | 13% | 32% |
| 0.30 | 30 | 19 | 8 | 12% | 7% | 35% |
| 0.35 | 27 | 22 | 6 | 0% | 0% | 38% |
| 0.40 | 23 | 26 | 5 | 0% | 0% | 47% |
| 0.50 | 17 | 32 | 2 | 0% | 0% | 56% |

### expiration_type

- role: `ENUM3` · abstain target: `not_specified` · n: 49 · baseline acc: 47% · mean margin: 0.534

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `not_specified` | 21 | 0.552 | 0.000 – 1.000 |
| `perpetual` | 6 | 0.668 | 0.207 – 0.954 |
| `specific_date` | 22 | 0.480 | 0.047 – 1.000 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 28 | 46% | 46% | 0% |
| 0.05 | 47 | 2 | 27 | 48% | 46% | 5% |
| 0.10 | 42 | 7 | 24 | 50% | 43% | 14% |
| 0.15 | 38 | 11 | 22 | 55% | 43% | 24% |
| 0.20 | 36 | 13 | 21 | 52% | 39% | 29% |
| 0.25 | 34 | 15 | 20 | 50% | 36% | 33% |
| 0.30 | 34 | 15 | 20 | 50% | 36% | 33% |
| 0.35 | 29 | 20 | 16 | 56% | 32% | 38% |
| 0.40 | 29 | 20 | 16 | 56% | 32% | 38% |
| 0.50 | 24 | 25 | 12 | 67% | 29% | 43% |

