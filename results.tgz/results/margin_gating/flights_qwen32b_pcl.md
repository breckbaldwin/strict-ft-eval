## flights_qwen32b_pcl

- **Schema:** `data/Flights_1_schema_pcl.json`
- **Data:** `data/Flights_1_test_pcl.jsonl`
- **Model:** `_`
- **Fields gated (5):** `passengers`, `seating_class`, `number_stops`, `refundable`, `airlines`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `passengers` | ENUM4 | — | 50 | 100% | 0.999 |
| `seating_class` | ENUM4 | — | 50 | 100% | 0.986 |
| `number_stops` | ENUM2 | — | 50 | 76% | 0.822 |
| `refundable` | ENUM3 | `ambiguous` | 50 | 98% | 0.961 |
| `airlines` | ENUM8 | — | 50 | 88% | 0.912 |

### passengers

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 100% · mean margin: 0.999

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `1` | 32 | 1.000 | 1.000 – 1.000 |
| `2` | 7 | 1.000 | 0.999 – 1.000 |
| `3` | 5 | 1.000 | 1.000 – 1.000 |
| `4` | 6 | 0.996 | 0.973 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 100% |
| 0.05 | 50 | 0 | 100% |
| 0.10 | 50 | 0 | 100% |
| 0.15 | 50 | 0 | 100% |
| 0.20 | 50 | 0 | 100% |
| 0.25 | 50 | 0 | 100% |
| 0.30 | 50 | 0 | 100% |
| 0.35 | 50 | 0 | 100% |
| 0.40 | 50 | 0 | 100% |
| 0.50 | 50 | 0 | 100% |

### seating_class

- role: `ENUM4` · abstain target: none · n: 50 · baseline acc: 100% · mean margin: 0.986

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Economy` | 44 | 0.984 | 0.513 – 1.000 |
| `Premium Economy` | 6 | 1.000 | 1.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 100% |
| 0.05 | 50 | 0 | 100% |
| 0.10 | 50 | 0 | 100% |
| 0.15 | 50 | 0 | 100% |
| 0.20 | 50 | 0 | 100% |
| 0.25 | 50 | 0 | 100% |
| 0.30 | 50 | 0 | 100% |
| 0.35 | 50 | 0 | 100% |
| 0.40 | 50 | 0 | 100% |
| 0.50 | 50 | 0 | 100% |

### number_stops

- role: `ENUM2` · abstain target: none · n: 50 · baseline acc: 76% · mean margin: 0.822

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `0` | 27 | 0.825 | 0.125 – 1.000 |
| `1` | 23 | 0.817 | 0.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 76% |
| 0.05 | 49 | 1 | 78% |
| 0.10 | 49 | 1 | 78% |
| 0.15 | 48 | 2 | 79% |
| 0.20 | 48 | 2 | 79% |
| 0.25 | 46 | 4 | 78% |
| 0.30 | 46 | 4 | 78% |
| 0.35 | 46 | 4 | 78% |
| 0.40 | 43 | 7 | 79% |
| 0.50 | 41 | 9 | 80% |

### refundable

- role: `ENUM3` · abstain target: `ambiguous` · n: 50 · baseline acc: 98% · mean margin: 0.961

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 9 | 0.799 | 0.125 – 1.000 |
| `True` | 5 | 0.974 | 0.881 – 1.000 |
| `ambiguous` | 36 | 1.000 | 0.998 – 1.000 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_ambiguous`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 14 | 93% | 93% | 0% |
| 0.05 | 50 | 0 | 14 | 93% | 93% | 0% |
| 0.10 | 50 | 0 | 14 | 93% | 93% | 0% |
| 0.15 | 49 | 1 | 13 | 100% | 93% | 0% |
| 0.20 | 48 | 2 | 12 | 100% | 86% | 0% |
| 0.25 | 48 | 2 | 12 | 100% | 86% | 0% |
| 0.30 | 48 | 2 | 12 | 100% | 86% | 0% |
| 0.35 | 48 | 2 | 12 | 100% | 86% | 0% |
| 0.40 | 48 | 2 | 12 | 100% | 86% | 0% |
| 0.50 | 48 | 2 | 12 | 100% | 86% | 0% |

### airlines

- role: `ENUM8` · abstain target: none · n: 50 · baseline acc: 88% · mean margin: 0.912

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `Air Canada` | 2 | 0.485 | 0.470 – 0.500 |
| `Alaska Airlines` | 5 | 0.874 | 0.628 – 1.000 |
| `American Airlines` | 22 | 0.878 | 0.041 – 1.000 |
| `Delta Airlines` | 10 | 0.998 | 0.976 – 1.000 |
| `Southwest Airlines` | 5 | 0.994 | 0.970 – 1.000 |
| `United Airlines` | 6 | 1.000 | 1.000 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 50 | 0 | 88% |
| 0.05 | 49 | 1 | 90% |
| 0.10 | 49 | 1 | 90% |
| 0.15 | 49 | 1 | 90% |
| 0.20 | 48 | 2 | 90% |
| 0.25 | 48 | 2 | 90% |
| 0.30 | 48 | 2 | 90% |
| 0.35 | 48 | 2 | 90% |
| 0.40 | 48 | 2 | 90% |
| 0.50 | 45 | 5 | 96% |

