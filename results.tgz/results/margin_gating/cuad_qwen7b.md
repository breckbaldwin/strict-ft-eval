## cuad_qwen7b

- **Schema:** `data/cuad_schema.json`
- **Data:** `data/cuad_test.jsonl`
- **Model:** `_`
- **Fields gated (11):** `has_anti_assignment`, `has_cap_on_liability`, `has_audit_rights`, `has_exclusivity`, `has_change_of_control`, `has_non_compete`, `has_liquidated_damages`, `has_most_favored_nation`, `governing_law`, `renewal_term`, `expiration_type`

### Per-field baseline summary

| Field | Role | abstain target | n | baseline acc | mean margin |
|---|---|---|---:|---:|---:|
| `has_anti_assignment` | BOOL | — | 49 | 22% | 0.987 |
| `has_cap_on_liability` | BOOL | — | 49 | 45% | 0.973 |
| `has_audit_rights` | BOOL | — | 49 | 61% | 0.821 |
| `has_exclusivity` | BOOL | — | 49 | 86% | 0.757 |
| `has_change_of_control` | BOOL | — | 49 | 86% | 0.675 |
| `has_non_compete` | BOOL | — | 49 | 84% | 0.722 |
| `has_liquidated_damages` | BOOL | — | 49 | 92% | 0.728 |
| `has_most_favored_nation` | BOOL | — | 49 | 96% | 0.905 |
| `governing_law` | ENUM12 | `not_specified` | 49 | 24% | 0.574 |
| `renewal_term` | ENUM6 | `not_specified` | 49 | 53% | 0.644 |
| `expiration_type` | ENUM3 | `not_specified` | 49 | 67% | 0.676 |

### has_anti_assignment

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 22% · mean margin: 0.987

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 11 | 1.000 | 1.000 – 1.000 |
| `True` | 38 | 0.984 | 0.461 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 22% |
| 0.05 | 49 | 0 | 22% |
| 0.10 | 49 | 0 | 22% |
| 0.15 | 49 | 0 | 22% |
| 0.20 | 49 | 0 | 22% |
| 0.25 | 49 | 0 | 22% |
| 0.30 | 49 | 0 | 22% |
| 0.35 | 49 | 0 | 22% |
| 0.40 | 49 | 0 | 22% |
| 0.50 | 48 | 1 | 23% |

### has_cap_on_liability

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 45% · mean margin: 0.973

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 23 | 0.976 | 0.509 – 1.000 |
| `True` | 26 | 0.970 | 0.760 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 45% |
| 0.05 | 49 | 0 | 45% |
| 0.10 | 49 | 0 | 45% |
| 0.15 | 49 | 0 | 45% |
| 0.20 | 49 | 0 | 45% |
| 0.25 | 49 | 0 | 45% |
| 0.30 | 49 | 0 | 45% |
| 0.35 | 49 | 0 | 45% |
| 0.40 | 49 | 0 | 45% |
| 0.50 | 49 | 0 | 45% |

### has_audit_rights

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 61% · mean margin: 0.821

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 24 | 0.920 | 0.509 – 1.000 |
| `True` | 25 | 0.727 | 0.303 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 61% |
| 0.05 | 49 | 0 | 61% |
| 0.10 | 49 | 0 | 61% |
| 0.15 | 49 | 0 | 61% |
| 0.20 | 49 | 0 | 61% |
| 0.25 | 49 | 0 | 61% |
| 0.30 | 49 | 0 | 61% |
| 0.35 | 47 | 2 | 64% |
| 0.40 | 46 | 3 | 65% |
| 0.50 | 44 | 5 | 66% |

### has_exclusivity

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 86% · mean margin: 0.757

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 32 | 0.821 | 0.000 – 1.000 |
| `True` | 17 | 0.638 | 0.062 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 86% |
| 0.05 | 48 | 1 | 88% |
| 0.10 | 45 | 4 | 87% |
| 0.15 | 45 | 4 | 87% |
| 0.20 | 44 | 5 | 89% |
| 0.25 | 42 | 7 | 90% |
| 0.30 | 42 | 7 | 90% |
| 0.35 | 40 | 9 | 92% |
| 0.40 | 39 | 10 | 92% |
| 0.50 | 36 | 13 | 94% |

### has_change_of_control

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 86% · mean margin: 0.675

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 40 | 0.708 | 0.000 – 1.000 |
| `True` | 9 | 0.529 | 0.062 – 0.994 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 86% |
| 0.05 | 48 | 1 | 88% |
| 0.10 | 45 | 4 | 87% |
| 0.15 | 41 | 8 | 90% |
| 0.20 | 40 | 9 | 90% |
| 0.25 | 39 | 10 | 92% |
| 0.30 | 39 | 10 | 92% |
| 0.35 | 36 | 13 | 94% |
| 0.40 | 36 | 13 | 94% |
| 0.50 | 33 | 16 | 97% |

### has_non_compete

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 84% · mean margin: 0.722

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 39 | 0.779 | 0.062 – 1.000 |
| `True` | 10 | 0.501 | 0.062 – 0.992 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 84% |
| 0.05 | 49 | 0 | 84% |
| 0.10 | 47 | 2 | 83% |
| 0.15 | 47 | 2 | 83% |
| 0.20 | 46 | 3 | 83% |
| 0.25 | 42 | 7 | 88% |
| 0.30 | 42 | 7 | 88% |
| 0.35 | 42 | 7 | 88% |
| 0.40 | 40 | 9 | 88% |
| 0.50 | 39 | 10 | 90% |

### has_liquidated_damages

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 92% · mean margin: 0.728

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 44 | 0.759 | 0.062 – 1.000 |
| `True` | 5 | 0.455 | 0.303 – 0.892 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 92% |
| 0.05 | 49 | 0 | 92% |
| 0.10 | 48 | 1 | 92% |
| 0.15 | 47 | 2 | 91% |
| 0.20 | 46 | 3 | 91% |
| 0.25 | 46 | 3 | 91% |
| 0.30 | 46 | 3 | 91% |
| 0.35 | 44 | 5 | 93% |
| 0.40 | 37 | 12 | 97% |
| 0.50 | 34 | 15 | 97% |

### has_most_favored_nation

- role: `BOOL` · abstain target: none · n: 49 · baseline acc: 96% · mean margin: 0.905

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `False` | 47 | 0.911 | 0.555 – 1.000 |
| `True` | 2 | 0.754 | 0.509 – 1.000 |

Threshold sweep:

No natural abstain-target in this field's enum; table shows coverage × committed accuracy only.

| threshold | commit | abstain | commit_acc |
|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 96% |
| 0.05 | 49 | 0 | 96% |
| 0.10 | 49 | 0 | 96% |
| 0.15 | 49 | 0 | 96% |
| 0.20 | 49 | 0 | 96% |
| 0.25 | 49 | 0 | 96% |
| 0.30 | 49 | 0 | 96% |
| 0.35 | 49 | 0 | 96% |
| 0.40 | 49 | 0 | 96% |
| 0.50 | 49 | 0 | 96% |

### governing_law

- role: `ENUM12` · abstain target: `not_specified` · n: 49 · baseline acc: 24% · mean margin: 0.574

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `California` | 4 | 0.589 | 0.278 – 0.846 |
| `Delaware` | 8 | 0.427 | 0.090 – 0.808 |
| `Florida` | 1 | 0.655 | 0.655 – 0.655 |
| `Illinois` | 2 | 0.613 | 0.422 – 0.804 |
| `Nevada` | 1 | 0.246 | 0.246 – 0.246 |
| `New York` | 8 | 0.535 | 0.053 – 0.863 |
| `Pennsylvania` | 2 | 0.916 | 0.892 – 0.939 |
| `People's Republic of China` | 1 | 0.947 | 0.947 – 0.947 |
| `Texas` | 2 | 0.877 | 0.753 – 1.000 |
| `not_specified` | 5 | 0.731 | 0.314 – 0.976 |
| `other` | 15 | 0.517 | 0.000 – 0.966 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 44 | 20% | 20% | 0% |
| 0.05 | 48 | 1 | 43 | 21% | 20% | 0% |
| 0.10 | 46 | 3 | 41 | 22% | 20% | 0% |
| 0.15 | 45 | 4 | 40 | 22% | 20% | 0% |
| 0.20 | 42 | 7 | 37 | 24% | 20% | 0% |
| 0.25 | 39 | 10 | 34 | 24% | 18% | 0% |
| 0.30 | 38 | 11 | 33 | 21% | 16% | 0% |
| 0.35 | 36 | 13 | 32 | 19% | 14% | 20% |
| 0.40 | 35 | 14 | 31 | 19% | 14% | 20% |
| 0.50 | 30 | 19 | 26 | 23% | 14% | 20% |

### renewal_term

- role: `ENUM6` · abstain target: `not_specified` · n: 49 · baseline acc: 53% · mean margin: 0.644

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `fixed_term` | 6 | 0.600 | 0.318 – 0.764 |
| `not_specified` | 34 | 0.672 | 0.000 – 0.999 |
| `perpetual` | 1 | 0.864 | 0.864 – 0.864 |
| `successive_1_year` | 7 | 0.593 | 0.161 – 0.915 |
| `successive_multi_year` | 1 | 0.086 | 0.086 – 0.086 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 15 | 0% | 0% | 0% |
| 0.05 | 46 | 3 | 15 | 0% | 0% | 9% |
| 0.10 | 44 | 5 | 14 | 0% | 0% | 12% |
| 0.15 | 44 | 5 | 14 | 0% | 0% | 12% |
| 0.20 | 40 | 9 | 13 | 0% | 0% | 21% |
| 0.25 | 39 | 10 | 13 | 0% | 0% | 24% |
| 0.30 | 38 | 11 | 13 | 0% | 0% | 26% |
| 0.35 | 35 | 14 | 11 | 0% | 0% | 29% |
| 0.40 | 35 | 14 | 11 | 0% | 0% | 29% |
| 0.50 | 32 | 17 | 9 | 0% | 0% | 32% |

### expiration_type

- role: `ENUM3` · abstain target: `not_specified` · n: 49 · baseline acc: 67% · mean margin: 0.676

Margin by gold class:

| target | n | mean margin | range |
|---|---:|---:|---|
| `not_specified` | 21 | 0.622 | 0.059 – 0.993 |
| `perpetual` | 6 | 0.430 | 0.125 – 0.898 |
| `specific_date` | 22 | 0.795 | 0.281 – 1.000 |

Threshold sweep:

`retained_on_disc = disc_correct / total_gold_specified`  ·  `undisc_abstain = correct_abstention_rate_on_gold_not_specified`

| threshold | commit | abstain | spec_commits | commit_acc | retained_on_spec | undisc_abstain |
|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 49 | 0 | 28 | 71% | 71% | 0% |
| 0.05 | 49 | 0 | 28 | 71% | 71% | 0% |
| 0.10 | 48 | 1 | 28 | 71% | 71% | 5% |
| 0.15 | 47 | 2 | 27 | 70% | 68% | 5% |
| 0.20 | 46 | 3 | 26 | 73% | 68% | 5% |
| 0.25 | 44 | 5 | 25 | 76% | 68% | 10% |
| 0.30 | 42 | 7 | 24 | 79% | 68% | 14% |
| 0.35 | 42 | 7 | 24 | 79% | 68% | 14% |
| 0.40 | 38 | 11 | 23 | 83% | 68% | 29% |
| 0.50 | 34 | 15 | 22 | 86% | 68% | 43% |

